window.requestAnimationFrame = window.requestAnimationFrame
	|| window.mozRequestAnimationFrame
	|| window.webkitRequestAnimationFrame
	|| window.msRequestAnimationFrame
	|| function (f) { return setTimeout(f, 1000 / 60) }

class Game {
	constructor() {
		this.canvas = document.getElementById("myCanvas");
		this.ctx = this.canvas.getContext("2d");
		this.sprites = [];


	}

	update() {
		var ldeletedArray = [];


		var lSpritesLength = this.sprites.length;
		for (var i = 0; i < lSpritesLength; i++) {


			if (this.sprites[i].update()) {
				ldeletedArray.push(this.sprites[i]);
			}
		}

		for (var i = 0; i < ldeletedArray.length; i++) {
			var index = this.sprites.indexOf(ldeletedArray[i]);
			this.sprites.splice(index, 1);
		}
	}

	addSprites(pSprites) {
		this.sprites.push(pSprites);
	}

	draw() {
		this.ctx.clearRect(0, 0, 800, 600);
		var lSpritesLength = this.sprites.length;
		for (var i = 0; i < lSpritesLength; i++)
			this.sprites[i].draw(this.ctx);
	}
}

class Sprite {
	constructor() {
	}

	update() {
	}

	draw(pCtx) {
	}
}




