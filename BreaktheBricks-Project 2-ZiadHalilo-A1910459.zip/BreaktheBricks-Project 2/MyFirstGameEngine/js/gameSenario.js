var canvas = document.getElementById("myCanvas");
var ctxs = canvas.getContext("2d");
var tableImage = new Image();
tableImage.src = "image/breakB.jpg";

//Setting the table width&Height equal to canvas width&height
tableImage.width = canvas.width;
tableImage.height = canvas.height;
var tableWidth = tableImage.width;
var tableHeight = tableImage.height;

// Handle keyboard controls
var keysDown = {};

addEventListener("keydown", function (e) {

	keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) {
	delete keysDown[e.keyCode];
}, false);



class Ball extends Sprite {
	constructor(centerX, centerY, radius, color, user) {
		super();
		this.cX = centerX;
		this.cY = centerY;
		this.radius = radius;
		this.color = color;
		this.dx = 2;
		this.dy = -2;
		this.user = user;
		this.userwin;
		this.play = false;
		this.userloss = false;
		this.userW = false;
		this.pause = 0; //paddle stops moving in case the game didnt start
		this.begin = this.user.horizontalspeed; //paddle starts moving when the game starts
		this.gameover = false;

	}

	update() {

		if (this.cY + this.radius < 140) {
			this.dy = 2;
		}
		if (this.cX + this.radius < 130) {
			this.dx = 2;
		}
		if (this.cX + this.radius > tableWidth - 110) {
			this.dx = -2;
		}
		if (this.cY - this.radius > tableHeight - 145) {
			this.play = false;
			this.gameover = true;
		}

		if (this.dx > 0 && this.dy > 0) {
			if ((this.cX > user.x &&
				this.cX < user.x + user.width)
				&& this.cY + this.radius > user.y) {
				this.dx = 2;
				this.dy = -2;
			}



		}

		if (this.dx < 0 && this.dy > 0) {
			if ((this.cX > user.x &&
				this.cX < user.x + user.width)
				&& this.cY + this.radius > user.y) {
				this.dx = -2;
				this.dy = -2;
			}


		}




		this.cX += this.dx;
		this.cY += this.dy;

		if (13 in keysDown) {
			this.play = true;
			this.gameover = false;
			this.user.x = this.user.x;
			this.user.y = this.user.y;
			this.user.horizontalspeed = this.begin;
		}
	}


	draw(ctx) {

		if (!this.play) {
			console.log("not play");
			this.cX = (user.x + user.width / 2);
			this.cY = (user.y + user.height / 2) - 15;
			user.x = tableWidth - 440;
			user.y = tableHeight - 140;
			user.horizontalspeed = this.pause;
			ctx.fillStyle = "#FFFFFF";
			ctx.font = "19px Courier New";
			ctx.fillText("\t\tPRESS ENTER TO PLAY " + "", tableWidth - 528, tableHeight - 260);
			ctx.fillText("Score: " + this.userwin, tableWidth / 8, tableHeight / 7);
			ctx.beginPath();
			ctx.arc(this.cX, this.cY, this.radius, 2 * Math.PI, false);
			ctx.fillStyle = this.color;
			ctx.fill();


		} else {
			console.log("play");
			user.horizontalspeed = this.begin;
			ctx.fillStyle = "#FFFFFF";
			ctx.font = "19px Courier New";
			ctx.fillText("Score: " + this.userwin, tableWidth / 8, tableHeight / 7);
			ctx.clearRect(this.cX, this.cY, 0, 0)
			ctx.beginPath();
			ctx.arc(this.cX, this.cY, this.radius, 2 * Math.PI, false);
			ctx.fillStyle = this.color;
			ctx.fill();
		}
	}
}
class Background extends Sprite {
	constructor(image, width, height) {
		super();
		this.image = image;
		this.width = width;
		this.height = height;
	}

	update() {

	}

	draw(ctx) {
		ctx.drawImage(this.image, 0, 0, this.width, this.height);
	}

}

class Bricks extends Sprite {
	constructor(x, y, width, height, color, ball) {
		super();
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
		this.ball = ball;
		this.break = 0;
		this.ball.userwin = this.break;

	}

	update() {

		if (this.ball.cY - this.ball.radius < this.y + this.height && this.ball.cY + this.ball.radius > this.y &&
			(this.ball.cX > this.x &&
				this.ball.cX < this.x + this.width)) {
			this.ball.dx = -2;
			this.ball.dy = 3;

			this.ball.userwin++;
			return true;
		}

	}

	draw(context) {
		if (this.ball.gameover) {
			restartbricks();
			this.ball.gameover = false;
			this.ball.userwin = 0;


		}

		// else {
		context.fillStyle = this.color;
		context.beginPath();
		context.rect(this.x, this.y, this.width, this.height);
		context.fill();
		//}
	}

}

class userController extends Sprite {
	constructor(x, y, width, height, color, horizontalspeed) {
		super();
		this.x = x / 2.25;
		this.y = y / 1.3;
		this.width = width;
		this.height = height;
		this.color = color;
		this.horizontalspeed = horizontalspeed;

	}

	update() {

		if (39 in keysDown) { // User holding left
			if (this.x < 590)
				this.x += this.horizontalspeed;
		}

		if (37 in keysDown) { // User holding right
			if (this.x >= 120.62)
				this.x -= this.horizontalspeed;
		}
	}


	draw(context) {
		context.fillStyle = this.color;
		context.beginPath();
		context.rect(this.x, this.y, this.width, this.height);
		context.fill();
	}
}
//02a8d5
var myGame = new Game();
var user = new userController(tableWidth, tableHeight, 90, 10, "#FFFFFF", 5);
var brick;
var ball = new Ball(user.x, user.y, 8, "#f57f28", user);
myGame.addSprites(new Background(tableImage, tableWidth, tableHeight));
myGame.addSprites(user);
myGame.addSprites(ball);


function restartbricks() {

	var k = 0;
	for (let i = 1; i <= 4; i++) {
		for (let j = 1; j <= 4; j += 0.6) {
			brick = new Bricks((j) * 148, (i + k) * 160, 70, 20, "#f65679", ball);
			myGame.addSprites(brick);
			if (j % 4 == 0) {
				k -= 0.8;
			}
		}

	}

}



var k = 0;
for (let i = 1; i <= 4; i++) {
	for (let j = 1; j <= 4; j += 0.6) {
		brick = new Bricks((j) * 148, (i + k) * 160, 70, 20, "#f65679", ball);
		myGame.addSprites(brick);
		if (j % 4 == 0) {
			k -= 0.8;
		}
	}

}



function animate() {

	myGame.update();
	myGame.draw();

	requestAnimationFrame(animate);

}
animate();







